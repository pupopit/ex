<!DOCTYPE html>
<html>
<head>
    <title>Student Management</title>
</head>
<body>
    <a href="add_student.php"><button>Add Student</button></a>
    <a href="view_students.php"><button>View Students</button></a>
</body>
</html>